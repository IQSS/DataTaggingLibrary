DataTags: consists of Greeting, Subject,X.

Greeting: one of ignore, hi, hello, _hug_.
Subject: some of world, planet, moon, unrecognizedOrbitingObject.

X:some of a, b,c,d,e,f.