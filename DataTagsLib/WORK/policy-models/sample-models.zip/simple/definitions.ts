<*
Simple questionnaire, for tool testing
*>

BurritoLunch: consists of Bag , Burrito, Extras.
Bag: one of plastic, banana_leaf, paper.
Burrito: consists of Wrap , Main , Side.
Wrap: one of corn , full_grain , wheat.
Main: one of  chicken, tofu, beef.
Side: some of rice , corn , guacamole ,cream, cheese.
Extras[Added here to test whether keywords can be values to be set in  set nodes]: one of ask, set, get.
