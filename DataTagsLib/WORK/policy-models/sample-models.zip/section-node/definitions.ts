Base: consists of Cats, Dogs, Rice.

Cats: some of Tom, Shmil, Mitzi.

Dogs: some of Rex, Pluto, Lassie.

Rice: one of White, Full.
